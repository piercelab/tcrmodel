---
title: Arrow up square
layout: icon
categories:
  - Shape Arrows
tags:
  - arrow
  - square
---
